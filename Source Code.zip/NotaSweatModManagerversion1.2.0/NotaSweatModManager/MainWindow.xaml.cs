using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using Forms = System.Windows.Forms;
using MediaColor = System.Windows.Media.Color;
using WpfMessageBox = System.Windows.MessageBox;

namespace NotaSweatModManager;

public partial class MainWindow : Window
{
    private string pluginsFolder = "";
    private string gameExePath = "";

    private readonly List<ModInfo> availableMods = new()
    {
        new ModInfo("Utilla", "sirkingbinx", "Utilla", "1.7.0", "Core library / dependency mod.", null, Array.Empty<string>()),
        new ModInfo("Bingus Nametags++", "sirkingbinx", "BingusNametagsPlusPlus", "1.5.0", "Nametag mod.", null, new[] { "Utilla" }),
        new ModInfo("Oculus Report Menu", "sirkingbinx", "OculusReportMenu", "v2.4.0", "Only installs assets/files that contain BepInEx.", "BepInEx", Array.Empty<string>()),
        new ModInfo("Several Bees", "sevvy-wevvy", "Several-Bees", "2.5.1", "Required dependency for Gorilla Optimizer.", null, Array.Empty<string>()),
        new ModInfo("Gorilla Optimizer", "sevvy-wevvy", "Gorilla-Optimizer", "1.1.0", "Optimization mod. Requires Several Bees.", null, new[] { "Several Bees" }),
        new ModInfo("StreamCodeMOD BepInEx", "CheffyCaster", "StreamCodeMOD-BEPINX", "LIVE2", "Stream code mod.", null, Array.Empty<string>()),
        new ModInfo("No Forest Barrier", "SilvazWasTaken", "NoForestBarrier", "1.0.1", "Removes the forest barrier.", null, Array.Empty<string>()),
        new ModInfo("FNAF Jumpscare", "quoote", "FNAFJumpscare", "1.0.0", "FNAF jumpscare mod.", null, Array.Empty<string>()),
        new ModInfo("Quick Leave", "quoote", "QuickLeave", "1.0.0", "Quick leave mod.", null, Array.Empty<string>())
    };

    public MainWindow()
    {
        InitializeComponent();

        MouseLeftButtonDown += (_, __) => DragMove();

        AvailableModsCards.ItemsSource = availableMods;

        StartGradientAnimation();

        AddLog("UI initialized.");
        AutoDetectInstall();
        ShowInstalledMods();
    }

    private void StartGradientAnimation()
    {
        try
        {
            AnimateGradientStop(GradientStopA, MediaColor.FromRgb(0x2B, 0x12, 0x4B));
            AnimateGradientStop(GradientStopB, MediaColor.FromRgb(0x7E, 0x3D, 0xFF));
            AnimateGradientStop(GradientStopC, MediaColor.FromRgb(0xD8, 0x9C, 0xFF));
        }
        catch
        {
            // Static gradient remains if animation fails.
        }
    }

    private static void AnimateGradientStop(GradientStop stop, MediaColor targetColor)
    {
        ColorAnimation animation = new()
        {
            To = targetColor,
            Duration = TimeSpan.FromSeconds(7),
            AutoReverse = true,
            RepeatBehavior = RepeatBehavior.Forever
        };

        stop.BeginAnimation(GradientStop.ColorProperty, animation);
    }

    private void BrowseMods_Click(object sender, RoutedEventArgs e)
    {
        ShowBrowseMods();
    }

    private void InstalledMods_Click(object sender, RoutedEventArgs e)
    {
        ShowInstalledMods();
    }

    private void Utilities_Click(object sender, RoutedEventArgs e)
    {
        ShowUtilities();
    }

    private async void ShowBrowseMods()
    {
        PageTitleText.Text = "Browse Mods";
        BrowsePanel.Visibility = Visibility.Visible;
        InstalledPanel.Visibility = Visibility.Collapsed;
        UtilitiesPanel.Visibility = Visibility.Collapsed;
        ConsolePanel.Visibility = Visibility.Collapsed;
        ConsoleRow.Height = new GridLength(0);

        AvailableModsCards.ItemsSource = null;
        AvailableModsCards.ItemsSource = availableMods;

        await Task.Delay(20);
        AnimateModCards();
        AnimateActiveTab(BrowsePanel);
    }

    private async void ShowInstalledMods()
    {
        PageTitleText.Text = "Installed Mods";
        BrowsePanel.Visibility = Visibility.Collapsed;
        InstalledPanel.Visibility = Visibility.Visible;
        UtilitiesPanel.Visibility = Visibility.Collapsed;
        ConsolePanel.Visibility = Visibility.Visible;
        ConsoleRow.Height = new GridLength(205);

        await Task.Delay(20);
        AnimateActiveTab(InstalledPanel);
        AnimateActiveTab(ConsolePanel);
    }

    private async void ShowUtilities()
    {
        PageTitleText.Text = "Utilities";
        BrowsePanel.Visibility = Visibility.Collapsed;
        InstalledPanel.Visibility = Visibility.Collapsed;
        UtilitiesPanel.Visibility = Visibility.Visible;
        ConsolePanel.Visibility = Visibility.Visible;
        ConsoleRow.Height = new GridLength(205);

        await Task.Delay(20);
        AnimateActiveTab(UtilitiesPanel);
        AnimateActiveTab(ConsolePanel);
    }

    private void AnimateActiveTab(UIElement element)
    {
        element.Opacity = 0;
        element.RenderTransform = new TranslateTransform(0, 14);

        DoubleAnimation fade = new()
        {
            To = 1,
            Duration = TimeSpan.FromSeconds(0.15)
        };

        DoubleAnimation slide = new()
        {
            To = 0,
            Duration = TimeSpan.FromSeconds(0.15)
        };

        element.BeginAnimation(OpacityProperty, fade);

        if (element.RenderTransform is TranslateTransform transform)
        {
            transform.BeginAnimation(TranslateTransform.YProperty, slide);
        }
    }

    private void AnimateModCards()
    {
        foreach (ContentPresenter presenter in FindVisualChildren<ContentPresenter>(AvailableModsCards))
        {
            presenter.Opacity = 0;
            presenter.RenderTransform = new TranslateTransform(0, 14);

            DoubleAnimation fade = new()
            {
                To = 1,
                Duration = TimeSpan.FromSeconds(0.15)
            };

            DoubleAnimation slide = new()
            {
                To = 0,
                Duration = TimeSpan.FromSeconds(0.15)
            };

            presenter.BeginAnimation(OpacityProperty, fade);
            ((TranslateTransform)presenter.RenderTransform).BeginAnimation(TranslateTransform.YProperty, slide);
        }
    }

    private static IEnumerable<T> FindVisualChildren<T>(DependencyObject parent) where T : DependencyObject
    {
        if (parent == null)
            yield break;

        int childCount = VisualTreeHelper.GetChildrenCount(parent);

        for (int i = 0; i < childCount; i++)
        {
            DependencyObject child = VisualTreeHelper.GetChild(parent, i);

            if (child is T typedChild)
                yield return typedChild;

            foreach (T descendant in FindVisualChildren<T>(child))
                yield return descendant;
        }
    }

    private void MinimizeButton_Click(object sender, RoutedEventArgs e)
    {
        WindowState = WindowState.Minimized;
    }

    private void ExitButton_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }

    private void AddLog(string text)
    {
        LogBox.AppendText($"[{DateTime.Now:HH:mm:ss}] {text}\n");
        LogBox.ScrollToEnd();
    }

    private void AutoDetectInstall()
    {
        string[] possibleSteamRoots =
        {
            @"C:\Program Files (x86)\Steam\steamapps\common\Gorilla Tag",
            @"C:\Program Files\Steam\steamapps\common\Gorilla Tag"
        };

        foreach (string root in possibleSteamRoots)
        {
            string possiblePlugins = Path.Combine(root, "BepInEx", "plugins");
            string possibleGameExe = Path.Combine(root, "Gorilla Tag.exe");

            if (Directory.Exists(possiblePlugins) && string.IsNullOrWhiteSpace(pluginsFolder))
            {
                pluginsFolder = possiblePlugins;
                FolderPathText.Text = $"Plugins folder: {pluginsFolder}";
                AddLog("Automatically found plugins folder.");
                RefreshMods();
            }

            if (File.Exists(possibleGameExe) && string.IsNullOrWhiteSpace(gameExePath))
            {
                gameExePath = possibleGameExe;
                AddLog("Automatically found Gorilla Tag executable.");
            }
        }

        if (string.IsNullOrWhiteSpace(pluginsFolder))
        {
            FolderPathText.Text = "Please find the plugins folder.";
            AddLog("Could not automatically find the plugins folder.");
            WpfMessageBox.Show(
                "Please find the plugins folder.",
                "Plugins Folder Not Found",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }
    }


private void UninstallSelectedMod_Click(object sender, RoutedEventArgs e)
{
    if (InstalledModsList.SelectedItem is not string selectedFileName)
    {
        AddLog("No installed mod selected.");
        return;
    }

    if (string.IsNullOrWhiteSpace(pluginsFolder) || !Directory.Exists(pluginsFolder))
    {
        AddLog("Plugins folder does not exist.");
        return;
    }

    try
    {
        string sourcePath = Path.Combine(pluginsFolder, selectedFileName);

        if (!File.Exists(sourcePath))
        {
            AddLog("Selected mod file could not be found.");
            RefreshMods();
            return;
        }

        string downloadsFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            "Downloads");

        Directory.CreateDirectory(downloadsFolder);

        string destinationPath = Path.Combine(downloadsFolder, selectedFileName);

        if (File.Exists(destinationPath))
        {
            string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(selectedFileName);
            string extension = Path.GetExtension(selectedFileName);
            string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            destinationPath = Path.Combine(downloadsFolder, $"{fileNameWithoutExtension}_{timestamp}{extension}");
        }

        File.Move(sourcePath, destinationPath);

        AddLog($"Uninstalled mod and moved it to Downloads: {Path.GetFileName(destinationPath)}");
        RefreshMods();
    }
    catch (Exception ex)
    {
        AddLog($"Uninstall failed: {ex.Message}");
    }
}

private void OpenPluginsFolder_Click(object sender, RoutedEventArgs e)
{
    if (!EnsurePluginsFolder())
        return;

    OpenFolder(pluginsFolder, "plugins folder");
}

private void OpenGameFolder_Click(object sender, RoutedEventArgs e)
{
    string gameFolder = GetGameFolder();

    if (string.IsNullOrWhiteSpace(gameFolder))
    {
        AddLog("Could not locate game folder.");
        return;
    }

    OpenFolder(gameFolder, "game folder");
}

private void OpenGameDataFolder_Click(object sender, RoutedEventArgs e)
{
    string gameFolder = GetGameFolder();

    if (string.IsNullOrWhiteSpace(gameFolder))
    {
        AddLog("Could not locate game folder.");
        return;
    }

    string dataFolder = Path.Combine(gameFolder, "Gorilla Tag_Data");

    if (!Directory.Exists(dataFolder))
    {
        AddLog("Could not locate Gorilla Tag_Data folder.");
        return;
    }

    OpenFolder(dataFolder, "Gorilla Tag Data folder");
}

private string GetGameFolder()
{
    if (!string.IsNullOrWhiteSpace(gameExePath) && File.Exists(gameExePath))
        return Path.GetDirectoryName(gameExePath) ?? "";

    string[] possibleGamePaths =
    {
        @"C:\Program Files (x86)\Steam\steamapps\common\Gorilla Tag\Gorilla Tag.exe",
        @"C:\Program Files\Steam\steamapps\common\Gorilla Tag\Gorilla Tag.exe"
    };

    foreach (string path in possibleGamePaths)
    {
        if (File.Exists(path))
        {
            gameExePath = path;
            return Path.GetDirectoryName(path) ?? "";
        }
    }

    if (!string.IsNullOrWhiteSpace(pluginsFolder))
    {
        DirectoryInfo? directory = new DirectoryInfo(pluginsFolder);

        while (directory != null)
        {
            if (directory.Name.Equals("Gorilla Tag", StringComparison.OrdinalIgnoreCase))
                return directory.FullName;

            directory = directory.Parent;
        }
    }

    return "";
}

private void OpenFolder(string folderPath, string displayName)
{
    try
    {
        if (!Directory.Exists(folderPath))
        {
            AddLog($"Could not find {displayName}.");
            return;
        }

        Process.Start(new ProcessStartInfo
        {
            FileName = folderPath,
            UseShellExecute = true
        });

        AddLog($"Opened {displayName}.");
    }
    catch (Exception ex)
    {
        AddLog($"Could not open {displayName}: {ex.Message}");
    }
}


    private void CreateRestoreMods_Click(object sender, RoutedEventArgs e)
    {
        string backupRoot = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Dependencies", "Mod Backups");
        Directory.CreateDirectory(backupRoot);

        var backups = Directory.GetDirectories(backupRoot);

        var result = WpfMessageBox.Show(
            "Yes = Create Backup\nNo = Restore Backup",
            "Mod Backup Manager",
            MessageBoxButton.YesNoCancel,
            MessageBoxImage.Question);

        if (result == MessageBoxResult.Yes)
        {
            string name = Microsoft.VisualBasic.Interaction.InputBox(
                "Enter a backup name:",
                "Create Backup",
                $"Backup_{DateTime.Now:yyyyMMdd}");

            if (string.IsNullOrWhiteSpace(name))
                return;

            string backupFolder = Path.Combine(backupRoot, name);
            Directory.CreateDirectory(backupFolder);

            foreach (string dll in Directory.GetFiles(pluginsFolder, "*.dll"))
            {
                File.Copy(dll, Path.Combine(backupFolder, Path.GetFileName(dll)), true);
            }

            AddLog($"Created backup: {name}");
            return;
        }

        if (result == MessageBoxResult.No)
        {
            if (backups.Length == 0)
            {
                AddLog("Please Create a Backup First!");
                WpfMessageBox.Show("Please Create a Backup First!", "No Backups Found");
                return;
            }

            string selectedBackup = backups[0];

            if (backups.Length > 1)
            {
                string names = string.Join("\n", backups.Select(Path.GetFileName));
                WpfMessageBox.Show($"Multiple backups found.\n\nCurrent auto-selection:\n{Path.GetFileName(backups[0])}\n\nAvailable:\n{names}",
                    "Backup Selection");
            }

            foreach (string dll in Directory.GetFiles(pluginsFolder, "*.dll"))
            {
                File.Delete(dll);
            }

            foreach (string dll in Directory.GetFiles(selectedBackup, "*.dll"))
            {
                File.Copy(dll, Path.Combine(pluginsFolder, Path.GetFileName(dll)), true);
            }

            RefreshMods();
            AddLog($"Restored backup: {Path.GetFileName(selectedBackup)}");
        }
    }

    private void ChooseFolder_Click(object sender, RoutedEventArgs e)
    {
        using var dialog = new Forms.FolderBrowserDialog
        {
            Description = "Please find the plugins folder"
        };

        if (dialog.ShowDialog() == Forms.DialogResult.OK)
        {
            pluginsFolder = dialog.SelectedPath;
            FolderPathText.Text = $"Plugins folder: {pluginsFolder}";
            AddLog("Plugins folder selected manually.");
            RefreshMods();
        }
    }

    private async void InstallModCard_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not System.Windows.Controls.Button button || button.Tag is not ModInfo mod)
        {
            AddLog("No mod selected.");
            return;
        }

        await InstallModWithDependencies(mod);
    }


private void ViewSource_Click(object sender, RoutedEventArgs e)
{
    if (sender is not System.Windows.Controls.Button button || button.Tag is not ModInfo mod)
    {
        AddLog("No source selected.");
        return;
    }

    try
    {
        Process.Start(new ProcessStartInfo
        {
            FileName = mod.SourceUrl,
            UseShellExecute = true
        });

        AddLog($"Opened source: {mod.Name}");
    }
    catch (Exception ex)
    {
        AddLog($"Could not open source: {ex.Message}");
    }
}

    private async Task InstallModWithDependencies(ModInfo mod)
    {
        if (!EnsurePluginsFolder())
            return;

        try
        {
            foreach (string dependencyName in mod.Dependencies)
            {
                ModInfo? dependency = availableMods.FirstOrDefault(m => m.Name == dependencyName);

                if (dependency != null && !IsLikelyInstalled(dependency))
                {
                    AddLog($"Installing required dependency: {dependency.Name}");
                    await DownloadAndInstallMod(dependency);
                }
            }

            await DownloadAndInstallMod(mod);
            RefreshMods();
        }
        catch (Exception ex)
        {
            AddLog($"Download failed: {ex.Message}");
        }
    }

    private async Task DownloadAndInstallMod(ModInfo mod)
    {
        AddLog($"Checking GitHub release: {mod.Owner}/{mod.Repo} @ {mod.Tag}");

        using HttpClient client = new();
        client.DefaultRequestHeaders.UserAgent.ParseAdd("NotaSweatModManager");

        string apiUrl = $"https://api.github.com/repos/{mod.Owner}/{mod.Repo}/releases/tags/{mod.Tag}";
        string json = await client.GetStringAsync(apiUrl);

        using JsonDocument doc = JsonDocument.Parse(json);
        JsonElement assets = doc.RootElement.GetProperty("assets");

        List<ReleaseAsset> matchingAssets = new();

        foreach (JsonElement asset in assets.EnumerateArray())
        {
            string name = asset.GetProperty("name").GetString() ?? "";
            string downloadUrl = asset.GetProperty("browser_download_url").GetString() ?? "";

            if (string.IsNullOrWhiteSpace(downloadUrl))
                continue;

            bool isDll = name.EndsWith(".dll", StringComparison.OrdinalIgnoreCase);
            bool isZip = name.EndsWith(".zip", StringComparison.OrdinalIgnoreCase);
            bool matchesHint = string.IsNullOrWhiteSpace(mod.AssetNameMustContain) ||
                               name.Contains(mod.AssetNameMustContain, StringComparison.OrdinalIgnoreCase);

            if ((isDll || isZip) && matchesHint)
                matchingAssets.Add(new ReleaseAsset(name, downloadUrl));
        }

        if (matchingAssets.Count == 0)
        {
            AddLog($"No compatible DLL/ZIP asset found for {mod.Name}.");
            return;
        }

        foreach (ReleaseAsset asset in matchingAssets)
        {
            byte[] bytes = await client.GetByteArrayAsync(asset.DownloadUrl);

            if (asset.Name.EndsWith(".dll", StringComparison.OrdinalIgnoreCase))
            {
                string destination = Path.Combine(pluginsFolder, asset.Name);
                await File.WriteAllBytesAsync(destination, bytes);
                AddLog($"Installed: {asset.Name}");
            }
            else if (asset.Name.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
            {
                string tempZip = Path.Combine(Path.GetTempPath(), asset.Name);
                await File.WriteAllBytesAsync(tempZip, bytes);
                InstallDllsFromZip(tempZip, mod);
            }
        }
    }

    private void InstallDllsFromZip(string zipPath, ModInfo mod)
    {
        using ZipArchive archive = ZipFile.OpenRead(zipPath);
        int installed = 0;

        foreach (ZipArchiveEntry entry in archive.Entries)
        {
            if (!entry.FullName.EndsWith(".dll", StringComparison.OrdinalIgnoreCase))
                continue;

            if (!string.IsNullOrWhiteSpace(mod.AssetNameMustContain) &&
                !entry.FullName.Contains(mod.AssetNameMustContain, StringComparison.OrdinalIgnoreCase))
                continue;

            string destination = Path.Combine(pluginsFolder, Path.GetFileName(entry.FullName));
            entry.ExtractToFile(destination, true);

            AddLog($"Installed from ZIP: {Path.GetFileName(entry.FullName)}");
            installed++;
        }

        if (installed == 0)
            AddLog($"No DLL files found inside ZIP: {Path.GetFileName(zipPath)}");
    }

    private bool EnsurePluginsFolder()
    {
        if (!string.IsNullOrWhiteSpace(pluginsFolder) && Directory.Exists(pluginsFolder))
            return true;

        FolderPathText.Text = "Please find the plugins folder.";
        AddLog("Please find the plugins folder before installing mods.");
        ChooseFolder_Click(this, new RoutedEventArgs());

        return !string.IsNullOrWhiteSpace(pluginsFolder) && Directory.Exists(pluginsFolder);
    }

    private bool IsLikelyInstalled(ModInfo mod)
    {
        if (!Directory.Exists(pluginsFolder))
            return false;

        string simplified = SimplifyName(mod.Name);

        return Directory.GetFiles(pluginsFolder, "*.dll").Any(file =>
        {
            string name = SimplifyName(Path.GetFileNameWithoutExtension(file));
            return name.Contains(simplified, StringComparison.OrdinalIgnoreCase) ||
                   simplified.Contains(name, StringComparison.OrdinalIgnoreCase);
        });
    }

    private static string SimplifyName(string value)
    {
        return value.Replace(" ", "", StringComparison.OrdinalIgnoreCase)
            .Replace("+", "", StringComparison.OrdinalIgnoreCase)
            .Replace("-", "", StringComparison.OrdinalIgnoreCase);
    }

    private void InstallLocalPlugin_Click(object sender, RoutedEventArgs e)
    {
        if (!EnsurePluginsFolder())
            return;

        Microsoft.Win32.OpenFileDialog dialog = new()
        {
            Filter = "DLL Files (*.dll)|*.dll",
            Title = "Select a plugin DLL"
        };

        if (dialog.ShowDialog() == true)
        {
            try
            {
                string fileName = Path.GetFileName(dialog.FileName);
                string destination = Path.Combine(pluginsFolder, fileName);

                File.Copy(dialog.FileName, destination, true);

                AddLog($"Installed local plugin: {fileName}");
                RefreshMods();
            }
            catch (Exception ex)
            {
                AddLog($"Install failed: {ex.Message}");
            }
        }
    }

    private void RefreshMods_Click(object sender, RoutedEventArgs e)
    {
        RefreshMods();
    }

    private void RefreshMods()
    {
        InstalledModsList.Items.Clear();

        if (string.IsNullOrWhiteSpace(pluginsFolder) || !Directory.Exists(pluginsFolder))
        {
            FolderPathText.Text = "Please find the plugins folder.";
            AddLog("Plugins folder does not exist.");
            return;
        }

        var dlls = Directory.GetFiles(pluginsFolder, "*.dll")
            .OrderBy(Path.GetFileName)
            .ToArray();

        foreach (var dll in dlls)
        {
            InstalledModsList.Items.Add(Path.GetFileName(dll));
        }

        AddLog($"Loaded {dlls.Length} installed mod(s).");
    }

    private void LaunchGame_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(gameExePath) || !File.Exists(gameExePath))
        {
            string[] possibleGamePaths =
            {
                @"C:\Program Files (x86)\Steam\steamapps\common\Gorilla Tag\Gorilla Tag.exe",
                @"C:\Program Files\Steam\steamapps\common\Gorilla Tag\Gorilla Tag.exe"
            };

            gameExePath = possibleGamePaths.FirstOrDefault(File.Exists) ?? "";
        }

        if (File.Exists(gameExePath))
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = gameExePath,
                UseShellExecute = true
            });

            AddLog("Launched Gorilla Tag.");
        }
        else
        {
            AddLog("Could not locate Gorilla Tag executable.");
        }
    }
}

public record ModInfo(
    string Name,
    string Owner,
    string Repo,
    string Tag,
    string Description,
    string? AssetNameMustContain,
    string[] Dependencies)
{
    public string SourceUrl => $"https://github.com/{Owner}/{Repo}";

    public string CardDetails
    {
        get
        {
            string deps = Dependencies.Length > 0
                ? $"Requires: {string.Join(", ", Dependencies)}"
                : "No listed dependencies.";

            return $"{Description}\n{Owner}/{Repo} @ {Tag}\n{deps}";
        }
    }
}

public record ReleaseAsset(string Name, string DownloadUrl);