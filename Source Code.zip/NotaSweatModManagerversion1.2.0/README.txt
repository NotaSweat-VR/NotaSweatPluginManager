NotaSweatModManager Animated Tabs Build

Changes:
- Every tab now has the same 0.15 second load-in animation style.
- Utilities button added to the top-right area, left of Browse Mods.
- Removed Refresh button from the sidebar.
- Install Local DLL remains renamed to Install DLL.
- Plugins folder utility says Open Plugins Folder.
- Gorilla data utility says Open Gorilla Tag Data.
- Kept uninstall selected mod, rounded purple scrollbars, View Source, minimize/exit buttons, and GitHub downloads.