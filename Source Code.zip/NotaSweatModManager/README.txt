NotaSweatModManager Normal Build + Rounded Purple Scrollbars

Changes:
- Removed single-file EXE publish settings.
- Returned to normal Visual Studio/.NET multi-file build output.
- Kept View Source buttons.
- Added fully custom rounded purple scrollbars.
- Browse Mods and console/log scrolling now use the purple rounded scrollbar style.