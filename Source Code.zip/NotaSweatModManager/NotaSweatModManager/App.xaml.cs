namespace NotaSweatModManager;

public partial class App : System.Windows.Application
{
}