using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using Forms = System.Windows.Forms;
using MediaColor = System.Windows.Media.Color;
using WpfMessageBox = System.Windows.MessageBox;

namespace NotaSweatModManager;

public partial class MainWindow : Window
{
    private string pluginsFolder = "";
    private string gameExePath = "";

    private readonly List<ModInfo> availableMods = new()
    {
        new ModInfo("Utilla", "sirkingbinx", "Utilla", "1.7.0", "Core library / dependency mod.", null, Array.Empty<string>()),
        new ModInfo("Bingus Nametags++", "sirkingbinx", "BingusNametagsPlusPlus", "1.5.0", "Nametag mod.", null, new[] { "Utilla" }),
        new ModInfo("Oculus Report Menu", "sirkingbinx", "OculusReportMenu", "v2.4.0", "Only installs assets/files that contain BepInEx.", "BepInEx", Array.Empty<string>()),
        new ModInfo("Several Bees", "sevvy-wevvy", "Several-Bees", "2.5.1", "Required dependency for Gorilla Optimizer.", null, Array.Empty<string>()),
        new ModInfo("Gorilla Optimizer", "sevvy-wevvy", "Gorilla-Optimizer", "1.1.0", "Optimization mod. Requires Several Bees.", null, new[] { "Several Bees" }),
        new ModInfo("StreamCodeMOD BepInEx", "CheffyCaster", "StreamCodeMOD-BEPINX", "LIVE2", "Stream code mod.", null, Array.Empty<string>()),
        new ModInfo("No Forest Barrier", "SilvazWasTaken", "NoForestBarrier", "1.0.1", "Removes the forest barrier.", null, Array.Empty<string>()),
        new ModInfo("FNAF Jumpscare", "quoote", "FNAFJumpscare", "1.0.0", "FNAF jumpscare mod.", null, Array.Empty<string>()),
        new ModInfo("Quick Leave", "quoote", "QuickLeave", "1.0.0", "Quick leave mod.", null, Array.Empty<string>())
    };

    public MainWindow()
    {
        InitializeComponent();

        MouseLeftButtonDown += (_, __) => DragMove();

        AvailableModsCards.ItemsSource = availableMods;

        StartGradientAnimation();

        AddLog("UI initialized.");
        AutoDetectInstall();
        ShowInstalledMods();
    }

    private void StartGradientAnimation()
    {
        try
        {
            AnimateGradientStop(GradientStopA, MediaColor.FromRgb(0x2B, 0x12, 0x4B));
            AnimateGradientStop(GradientStopB, MediaColor.FromRgb(0x7E, 0x3D, 0xFF));
            AnimateGradientStop(GradientStopC, MediaColor.FromRgb(0xD8, 0x9C, 0xFF));
        }
        catch
        {
            // Static gradient remains if animation fails.
        }
    }

    private static void AnimateGradientStop(GradientStop stop, MediaColor targetColor)
    {
        ColorAnimation animation = new()
        {
            To = targetColor,
            Duration = TimeSpan.FromSeconds(7),
            AutoReverse = true,
            RepeatBehavior = RepeatBehavior.Forever
        };

        stop.BeginAnimation(GradientStop.ColorProperty, animation);
    }

    private void BrowseMods_Click(object sender, RoutedEventArgs e)
    {
        ShowBrowseMods();
    }

    private void InstalledMods_Click(object sender, RoutedEventArgs e)
    {
        ShowInstalledMods();
    }

    private async void ShowBrowseMods()
    {
        PageTitleText.Text = "Browse Mods";
        BrowsePanel.Visibility = Visibility.Visible;
        InstalledPanel.Visibility = Visibility.Collapsed;
        ConsolePanel.Visibility = Visibility.Collapsed;
        ConsoleRow.Height = new GridLength(0);

        AvailableModsCards.ItemsSource = null;
        AvailableModsCards.ItemsSource = availableMods;

        await Task.Delay(20);
        AnimateModCards();
    }

    private void ShowInstalledMods()
    {
        PageTitleText.Text = "Installed Mods";
        BrowsePanel.Visibility = Visibility.Collapsed;
        InstalledPanel.Visibility = Visibility.Visible;
        ConsolePanel.Visibility = Visibility.Visible;
        ConsoleRow.Height = new GridLength(205);
    }

    private void AnimateModCards()
    {
        foreach (ContentPresenter presenter in FindVisualChildren<ContentPresenter>(AvailableModsCards))
        {
            presenter.Opacity = 0;
            presenter.RenderTransform = new TranslateTransform(0, 14);

            DoubleAnimation fade = new()
            {
                To = 1,
                Duration = TimeSpan.FromSeconds(0.15)
            };

            DoubleAnimation slide = new()
            {
                To = 0,
                Duration = TimeSpan.FromSeconds(0.15)
            };

            presenter.BeginAnimation(OpacityProperty, fade);
            ((TranslateTransform)presenter.RenderTransform).BeginAnimation(TranslateTransform.YProperty, slide);
        }
    }

    private static IEnumerable<T> FindVisualChildren<T>(DependencyObject parent) where T : DependencyObject
    {
        if (parent == null)
            yield break;

        int childCount = VisualTreeHelper.GetChildrenCount(parent);

        for (int i = 0; i < childCount; i++)
        {
            DependencyObject child = VisualTreeHelper.GetChild(parent, i);

            if (child is T typedChild)
                yield return typedChild;

            foreach (T descendant in FindVisualChildren<T>(child))
                yield return descendant;
        }
    }

    private void MinimizeButton_Click(object sender, RoutedEventArgs e)
    {
        WindowState = WindowState.Minimized;
    }

    private void ExitButton_Click(object sender, RoutedEventArgs e)
    {
        Close();
    }

    private void AddLog(string text)
    {
        LogBox.AppendText($"[{DateTime.Now:HH:mm:ss}] {text}\n");
        LogBox.ScrollToEnd();
    }

    private void AutoDetectInstall()
    {
        string[] possibleSteamRoots =
        {
            @"C:\Program Files (x86)\Steam\steamapps\common\Gorilla Tag",
            @"C:\Program Files\Steam\steamapps\common\Gorilla Tag"
        };

        foreach (string root in possibleSteamRoots)
        {
            string possiblePlugins = Path.Combine(root, "BepInEx", "plugins");
            string possibleGameExe = Path.Combine(root, "Gorilla Tag.exe");

            if (Directory.Exists(possiblePlugins) && string.IsNullOrWhiteSpace(pluginsFolder))
            {
                pluginsFolder = possiblePlugins;
                FolderPathText.Text = $"Plugins folder: {pluginsFolder}";
                AddLog("Automatically found plugins folder.");
                RefreshMods();
            }

            if (File.Exists(possibleGameExe) && string.IsNullOrWhiteSpace(gameExePath))
            {
                gameExePath = possibleGameExe;
                AddLog("Automatically found Gorilla Tag executable.");
            }
        }

        if (string.IsNullOrWhiteSpace(pluginsFolder))
        {
            FolderPathText.Text = "Please find the plugins folder.";
            AddLog("Could not automatically find the plugins folder.");
            WpfMessageBox.Show(
                "Please find the plugins folder.",
                "Plugins Folder Not Found",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }
    }

    private void ChooseFolder_Click(object sender, RoutedEventArgs e)
    {
        using var dialog = new Forms.FolderBrowserDialog
        {
            Description = "Please find the plugins folder"
        };

        if (dialog.ShowDialog() == Forms.DialogResult.OK)
        {
            pluginsFolder = dialog.SelectedPath;
            FolderPathText.Text = $"Plugins folder: {pluginsFolder}";
            AddLog("Plugins folder selected manually.");
            RefreshMods();
        }
    }

    private async void InstallModCard_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not System.Windows.Controls.Button button || button.Tag is not ModInfo mod)
        {
            AddLog("No mod selected.");
            return;
        }

        await InstallModWithDependencies(mod);
    }


private void ViewSource_Click(object sender, RoutedEventArgs e)
{
    if (sender is not System.Windows.Controls.Button button || button.Tag is not ModInfo mod)
    {
        AddLog("No source selected.");
        return;
    }

    try
    {
        Process.Start(new ProcessStartInfo
        {
            FileName = mod.SourceUrl,
            UseShellExecute = true
        });

        AddLog($"Opened source: {mod.Name}");
    }
    catch (Exception ex)
    {
        AddLog($"Could not open source: {ex.Message}");
    }
}

    private async Task InstallModWithDependencies(ModInfo mod)
    {
        if (!EnsurePluginsFolder())
            return;

        try
        {
            foreach (string dependencyName in mod.Dependencies)
            {
                ModInfo? dependency = availableMods.FirstOrDefault(m => m.Name == dependencyName);

                if (dependency != null && !IsLikelyInstalled(dependency))
                {
                    AddLog($"Installing required dependency: {dependency.Name}");
                    await DownloadAndInstallMod(dependency);
                }
            }

            await DownloadAndInstallMod(mod);
            RefreshMods();
        }
        catch (Exception ex)
        {
            AddLog($"Download failed: {ex.Message}");
        }
    }

    private async Task DownloadAndInstallMod(ModInfo mod)
    {
        AddLog($"Checking GitHub release: {mod.Owner}/{mod.Repo} @ {mod.Tag}");

        using HttpClient client = new();
        client.DefaultRequestHeaders.UserAgent.ParseAdd("NotaSweatModManager");

        string apiUrl = $"https://api.github.com/repos/{mod.Owner}/{mod.Repo}/releases/tags/{mod.Tag}";
        string json = await client.GetStringAsync(apiUrl);

        using JsonDocument doc = JsonDocument.Parse(json);
        JsonElement assets = doc.RootElement.GetProperty("assets");

        List<ReleaseAsset> matchingAssets = new();

        foreach (JsonElement asset in assets.EnumerateArray())
        {
            string name = asset.GetProperty("name").GetString() ?? "";
            string downloadUrl = asset.GetProperty("browser_download_url").GetString() ?? "";

            if (string.IsNullOrWhiteSpace(downloadUrl))
                continue;

            bool isDll = name.EndsWith(".dll", StringComparison.OrdinalIgnoreCase);
            bool isZip = name.EndsWith(".zip", StringComparison.OrdinalIgnoreCase);
            bool matchesHint = string.IsNullOrWhiteSpace(mod.AssetNameMustContain) ||
                               name.Contains(mod.AssetNameMustContain, StringComparison.OrdinalIgnoreCase);

            if ((isDll || isZip) && matchesHint)
                matchingAssets.Add(new ReleaseAsset(name, downloadUrl));
        }

        if (matchingAssets.Count == 0)
        {
            AddLog($"No compatible DLL/ZIP asset found for {mod.Name}.");
            return;
        }

        foreach (ReleaseAsset asset in matchingAssets)
        {
            byte[] bytes = await client.GetByteArrayAsync(asset.DownloadUrl);

            if (asset.Name.EndsWith(".dll", StringComparison.OrdinalIgnoreCase))
            {
                string destination = Path.Combine(pluginsFolder, asset.Name);
                await File.WriteAllBytesAsync(destination, bytes);
                AddLog($"Installed: {asset.Name}");
            }
            else if (asset.Name.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
            {
                string tempZip = Path.Combine(Path.GetTempPath(), asset.Name);
                await File.WriteAllBytesAsync(tempZip, bytes);
                InstallDllsFromZip(tempZip, mod);
            }
        }
    }

    private void InstallDllsFromZip(string zipPath, ModInfo mod)
    {
        using ZipArchive archive = ZipFile.OpenRead(zipPath);
        int installed = 0;

        foreach (ZipArchiveEntry entry in archive.Entries)
        {
            if (!entry.FullName.EndsWith(".dll", StringComparison.OrdinalIgnoreCase))
                continue;

            if (!string.IsNullOrWhiteSpace(mod.AssetNameMustContain) &&
                !entry.FullName.Contains(mod.AssetNameMustContain, StringComparison.OrdinalIgnoreCase))
                continue;

            string destination = Path.Combine(pluginsFolder, Path.GetFileName(entry.FullName));
            entry.ExtractToFile(destination, true);

            AddLog($"Installed from ZIP: {Path.GetFileName(entry.FullName)}");
            installed++;
        }

        if (installed == 0)
            AddLog($"No DLL files found inside ZIP: {Path.GetFileName(zipPath)}");
    }

    private bool EnsurePluginsFolder()
    {
        if (!string.IsNullOrWhiteSpace(pluginsFolder) && Directory.Exists(pluginsFolder))
            return true;

        FolderPathText.Text = "Please find the plugins folder.";
        AddLog("Please find the plugins folder before installing mods.");
        ChooseFolder_Click(this, new RoutedEventArgs());

        return !string.IsNullOrWhiteSpace(pluginsFolder) && Directory.Exists(pluginsFolder);
    }

    private bool IsLikelyInstalled(ModInfo mod)
    {
        if (!Directory.Exists(pluginsFolder))
            return false;

        string simplified = SimplifyName(mod.Name);

        return Directory.GetFiles(pluginsFolder, "*.dll").Any(file =>
        {
            string name = SimplifyName(Path.GetFileNameWithoutExtension(file));
            return name.Contains(simplified, StringComparison.OrdinalIgnoreCase) ||
                   simplified.Contains(name, StringComparison.OrdinalIgnoreCase);
        });
    }

    private static string SimplifyName(string value)
    {
        return value.Replace(" ", "", StringComparison.OrdinalIgnoreCase)
            .Replace("+", "", StringComparison.OrdinalIgnoreCase)
            .Replace("-", "", StringComparison.OrdinalIgnoreCase);
    }

    private void InstallLocalPlugin_Click(object sender, RoutedEventArgs e)
    {
        if (!EnsurePluginsFolder())
            return;

        Microsoft.Win32.OpenFileDialog dialog = new()
        {
            Filter = "DLL Files (*.dll)|*.dll",
            Title = "Select a plugin DLL"
        };

        if (dialog.ShowDialog() == true)
        {
            try
            {
                string fileName = Path.GetFileName(dialog.FileName);
                string destination = Path.Combine(pluginsFolder, fileName);

                File.Copy(dialog.FileName, destination, true);

                AddLog($"Installed local plugin: {fileName}");
                RefreshMods();
            }
            catch (Exception ex)
            {
                AddLog($"Install failed: {ex.Message}");
            }
        }
    }

    private void RefreshMods_Click(object sender, RoutedEventArgs e)
    {
        RefreshMods();
    }

    private void RefreshMods()
    {
        InstalledModsList.Items.Clear();

        if (string.IsNullOrWhiteSpace(pluginsFolder) || !Directory.Exists(pluginsFolder))
        {
            FolderPathText.Text = "Please find the plugins folder.";
            AddLog("Plugins folder does not exist.");
            return;
        }

        var dlls = Directory.GetFiles(pluginsFolder, "*.dll")
            .OrderBy(Path.GetFileName)
            .ToArray();

        foreach (var dll in dlls)
        {
            InstalledModsList.Items.Add(Path.GetFileName(dll));
        }

        AddLog($"Loaded {dlls.Length} installed mod(s).");
    }

    private void LaunchGame_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(gameExePath) || !File.Exists(gameExePath))
        {
            string[] possibleGamePaths =
            {
                @"C:\Program Files (x86)\Steam\steamapps\common\Gorilla Tag\Gorilla Tag.exe",
                @"C:\Program Files\Steam\steamapps\common\Gorilla Tag\Gorilla Tag.exe"
            };

            gameExePath = possibleGamePaths.FirstOrDefault(File.Exists) ?? "";
        }

        if (File.Exists(gameExePath))
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = gameExePath,
                UseShellExecute = true
            });

            AddLog("Launched Gorilla Tag.");
        }
        else
        {
            AddLog("Could not locate Gorilla Tag executable.");
        }
    }
}

public record ModInfo(
    string Name,
    string Owner,
    string Repo,
    string Tag,
    string Description,
    string? AssetNameMustContain,
    string[] Dependencies)
{
    public string SourceUrl => $"https://github.com/{Owner}/{Repo}";

    public string CardDetails
    {
        get
        {
            string deps = Dependencies.Length > 0
                ? $"Requires: {string.Join(", ", Dependencies)}"
                : "No listed dependencies.";

            return $"{Description}\n{Owner}/{Repo} @ {Tag}\n{deps}";
        }
    }
}

public record ReleaseAsset(string Name, string DownloadUrl);